# LANG BOT Android — Aplikasi Dashboard (WebView)

Project ini membuat APK Android yang membuka dashboard LANG BOT dalam aplikasi Android.

## Penting: arsitektur
APK ini adalah **aplikasi dashboard**, bukan mesin bot WhatsApp yang berjalan mandiri di dalam APK.
Bot Baileys/Node.js tetap harus berjalan pada server yang mendukung proses Node.js dan penyimpanan persisten. APK mengakses dashboard backend melalui HTTPS:

Android APK → HTTPS WebApp/API → Node.js Baileys → WhatsApp Group.

Menjalankan bot Baileys langsung di APK Android tidak disediakan dalam project ini karena pengelolaan sesi, proses latar belakang, stabilitas, dan pembatasan Android membuatnya tidak cocok sebagai cara deployment 24/7.

## 1. Deploy backend LANG BOT
Gunakan project backend LANG BOT. Deploy ke server yang mendukung Node.js long-running process dan persistent storage untuk folder `auth_info/` dan `data/`.
Jangan gunakan hosting statis saja. Atur HTTPS, `ADMIN_PASSWORD`, `SESSION_SECRET`, dan `COOKIE_SECURE=true`.

## 2. Atur URL dashboard APK
Buka file:
`app/src/main/java/id/langlabs/langbot/MainActivity.java`

Ganti:
`https://GANTI-DENGAN-DOMAIN-DASHBOARD-ANDA`

menjadi URL HTTPS dashboard milikmu, misalnya `https://bot.domainkamu.com`.
Jangan masukkan password atau token ke source code APK.

## 3. Build APK
1. Install Android Studio di komputer.
2. Pilih **Open** lalu pilih folder `LANG-BOT-Android`.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk APK rilis, gunakan **Build > Generate Signed Bundle / APK** dan simpan keystore dengan aman.

## 4. Bisa build hanya dari Android?
Build Android native dengan Gradle di HP tidak selalu mudah dan membutuhkan JDK, Android SDK, serta ruang penyimpanan besar. Cara paling stabil adalah Android Studio di PC atau workflow build cloud seperti GitHub Actions. Jangan unggah keystore atau kredensial rahasia ke repositori publik.

## Keamanan
- Gunakan HTTPS saja.
- Ubah password default backend.
- Jangan bagikan folder sesi WhatsApp `auth_info/`.
- APK tidak menyimpan kredensial admin; login dilakukan di dashboard.
- Pastikan dashboard memakai autentikasi dan pembatasan akses.
- Baileys adalah integrasi WhatsApp Web tidak resmi dan dapat membawa risiko pembatasan akun. Gunakan sesuai ketentuan WhatsApp.
