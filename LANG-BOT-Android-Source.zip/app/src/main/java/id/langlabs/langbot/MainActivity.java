package id.langlabs.langbot;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    // Ganti dengan URL HTTPS dashboard LANG BOT milikmu setelah backend di-deploy.
    private static final String DASHBOARD_URL = "https://GANTI-DENGAN-DOMAIN-DASHBOARD-ANDA";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Dibutuhkan untuk dashboard LANG BOT.
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        if (DASHBOARD_URL.contains("GANTI-DENGAN")) {
            Toast.makeText(this, "Atur DASHBOARD_URL di MainActivity.java terlebih dahulu.", Toast.LENGTH_LONG).show();
            webView.loadData(
                "<html><body style='font-family:sans-serif;background:#0b1020;color:white;padding:28px'>" +
                "<h2>LANG BOT</h2><p>Dashboard belum dikonfigurasi.</p>" +
                "<p>Edit DASHBOARD_URL di MainActivity.java dengan URL HTTPS server LANG BOT.</p></body></html>",
                "text/html", "UTF-8"
            );
        } else {
            webView.loadUrl(DASHBOARD_URL);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }
}
